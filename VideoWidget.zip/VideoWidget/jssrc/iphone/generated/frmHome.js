function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var flxStartup = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxStartup",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox008f4630265b64c",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxStartup.setDefaultUnit(kony.flex.DP);
    var flxHomeVideoApi = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxHomeVideoApi",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_b3a9b83fc5b442148781be04137b4b48,
        "skin": "CopyslFbox0eac78aab48a041",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHomeVideoApi.setDefaultUnit(kony.flex.DP);
    var lblVideoApi = new kony.ui.Label({
        "height": "100%",
        "id": "lblVideoApi",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0283360c36f3946",
        "text": "Video API",
        "top": "0%",
        "width": "95%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label0953fc05d330a43 = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "Label0953fc05d330a43",
        "isVisible": true,
        "left": "5.00%",
        "skin": "CopyslLabel0f19631990a5f44",
        "text": "Label",
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxHomeVideoApi.add(lblVideoApi, Label0953fc05d330a43);
    var flxVideoTypes = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxVideoTypes",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_429ba33b602a4b4ea74b113c18f0f911,
        "skin": "CopyslFbox0eac78aab48a041",
        "top": "10%",
        "width": "100%"
    }, {}, {});
    flxVideoTypes.setDefaultUnit(kony.flex.DP);
    var CopylblVideoApi084bad3367cca47 = new kony.ui.Label({
        "height": "100%",
        "id": "CopylblVideoApi084bad3367cca47",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0283360c36f3946",
        "text": "Video Types",
        "top": "0%",
        "width": "94%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0dc16382ea05944 = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel0dc16382ea05944",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0f19631990a5f44",
        "text": "Label",
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxVideoTypes.add(CopylblVideoApi084bad3367cca47, CopyLabel0dc16382ea05944);
    var flxVisibility = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxVisibility",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_d4f97c2ac1f14eddb13f5ac2583535d9,
        "skin": "CopyslFbox0eac78aab48a041",
        "top": "20%",
        "width": "100%"
    }, {}, {});
    flxVisibility.setDefaultUnit(kony.flex.DP);
    var CopylblVideoApi05dc73aec0eaf43 = new kony.ui.Label({
        "height": "100%",
        "id": "CopylblVideoApi05dc73aec0eaf43",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0283360c36f3946",
        "text": "Video Visibility",
        "top": "0%",
        "width": "94%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel005059c480ccb4f = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel005059c480ccb4f",
        "isVisible": true,
        "left": "5.00%",
        "skin": "CopyslLabel0f19631990a5f44",
        "text": "Label",
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxVisibility.add(CopylblVideoApi05dc73aec0eaf43, CopyLabel005059c480ccb4f);
    var flxEvents = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxEvents",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_888e079fd2ec48fab7d044989eacaa84,
        "skin": "CopyslFbox0eac78aab48a041",
        "top": "30%",
        "width": "100%"
    }, {}, {});
    flxEvents.setDefaultUnit(kony.flex.DP);
    var CopylblVideoApi0151e6c636e0740 = new kony.ui.Label({
        "height": "100%",
        "id": "CopylblVideoApi0151e6c636e0740",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0283360c36f3946",
        "text": "Video Events",
        "top": "0%",
        "width": "94%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel07c2e5341abfe4b = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel07c2e5341abfe4b",
        "isVisible": true,
        "left": "5.00%",
        "skin": "CopyslLabel0f19631990a5f44",
        "text": "Label",
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxEvents.add(CopylblVideoApi0151e6c636e0740, CopyLabel07c2e5341abfe4b);
    var flxRawBytes = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxRawBytes",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_454f0b9a4b6c4559b11d5833706d196a,
        "skin": "CopyslFbox0eac78aab48a041",
        "top": "40%",
        "width": "100%"
    }, {}, {});
    flxRawBytes.setDefaultUnit(kony.flex.DP);
    var CopylblVideoApi02272d05300684d = new kony.ui.Label({
        "height": "100%",
        "id": "CopylblVideoApi02272d05300684d",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0283360c36f3946",
        "text": "Video RawBytes",
        "top": "0%",
        "width": "94%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyLabel0afa8306119f946 = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel0afa8306119f946",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0f19631990a5f44",
        "text": "Label",
        "width": "100%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxRawBytes.add(CopylblVideoApi02272d05300684d, CopyLabel0afa8306119f946);
    var FlexContainer02fbc7641a6d24c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50%",
        "id": "FlexContainer02fbc7641a6d24c",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox003a830f1ae8741",
        "top": "50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer02fbc7641a6d24c.setDefaultUnit(kony.flex.DP);
    FlexContainer02fbc7641a6d24c.add();
    flxStartup.add(flxHomeVideoApi, flxVideoTypes, flxVisibility, flxEvents, flxRawBytes, FlexContainer02fbc7641a6d24c);
    frmHome.add(flxStartup);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0a9c2a861aad74e",
        "title": "Video Widget"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarConfig": {
            "renderTitleText": true,
            "prevFormTitle": false,
            "titleBarLeftSideView": "none",
            "titleBarRightSideView": "none"
        },
        "titleBarSkin": "CopyslTitleBar09807cf38a60f4f"
    });
    frmHome.info = {
        "kuid": "13215e93cf25414faca84b2e062bdebe"
    };
};