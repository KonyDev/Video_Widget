function addWidgetsfrmVideoEvents() {
    frmVideoEvents.setDefaultUnit(kony.flex.DP);
    var btnDynamicEvent = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed033c6e9e2d7ec42",
        "height": "9%",
        "id": "btnDynamicEvent",
        "isVisible": true,
        "left": "25%",
        "onClick": AS_Button_76c6de776edb4848b2e90c164eb13126,
        "skin": "CopyslButtonGlossBlue01f5a124ad37847",
        "text": "Dynamic Event",
        "top": "45%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var FlexContainer07eeee647c63b49 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "FlexContainer07eeee647c63b49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer07eeee647c63b49.setDefaultUnit(kony.flex.DP);
    FlexContainer07eeee647c63b49.add();
    frmVideoEvents.add(btnDynamicEvent, FlexContainer07eeee647c63b49);
};

function frmVideoEventsGlobals() {
    frmVideoEvents = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmVideoEvents,
        "enabledForIdleTimeout": false,
        "id": "frmVideoEvents",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm034ed6d943d4b48",
        "title": "Video Events"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarConfig": {
            "renderTitleText": true,
            "prevFormTitle": false,
            "titleBarLeftSideView": "button",
            "imageLeftSideView": "back.png",
            "titleBarRightSideView": "none"
        },
        "titleBarSkin": "CopyslTitleBar0da1ea6081bd34e"
    });
    frmVideoEvents.info = {
        "kuid": "b646904d3aef40728b147cf571c944c2"
    };
};