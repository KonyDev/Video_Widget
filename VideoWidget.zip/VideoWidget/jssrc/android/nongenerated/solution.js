//Api Function
/*************************************************************************************
 * Function:onPlay()
 * Description: function for playing video.
 * Author: Kony
 *************************************************************************************/
function onPlay(eventobject) {
    //kony.print('Video click Start ' + (typeof frmMethods.video21));
    frmVideoApi.video1.play();
    //kony.print('Video click end ');
}
/*************************************************************************************
 * Function:onPause()
 * Description: function for invoking Pause API.
 * Author: Kony
 *************************************************************************************/
function onPause(eventobject) {
    if (frmVideoApi.video1.isPlaying()) {
        frmVideoApi.video1.pause();
    }
}
/*************************************************************************************
 * Function:onStop()
 * Description: function for stopping the video.
 * Author: Kony
 *************************************************************************************/
function onStop(eventobject) {
    frmVideoApi.video1.stop();
}
/*************************************************************************************
 * Function:getPosition()
 * Description: function for getting the position of the video playing.
 * Author: Kony
 *************************************************************************************/
function getPosition(eventobject) {
    var millisec = frmVideoApi.video1.getCurrentPosition();
    var Pminutes = parseInt(millisec / 60000);
    var Pseconds = parseInt(((millisec / 60000) - Pminutes) * 60);
    frmVideoApi.lblDispPosition.text = "" + Pminutes + ":" + Pseconds;
}
/*************************************************************************************
 * Function:getDuration()
 * Description: function to display the total duration of the video.
 * Author: Kony
 *************************************************************************************/
function getDuration(eventobject) {
    var millisec = frmVideoApi.video1.getDuration();
    var Pminutes = parseInt(millisec / 60000);
    var Pseconds = parseInt(((millisec / 60000) - Pminutes) * 60);
    frmVideoApi.lblDispDuration.text = "" + Pminutes + ":" + Pseconds;
}
/*************************************************************************************
 * Function:videoPlaying()
 * Description: function to check wether the video is playing.
 * Author: Kony
 *************************************************************************************/
function videoPlaying(eventobject) {
    frmVideoApi.lblDispPlaying.text = "" + frmVideoApi.video1.isPlaying();
}
/*************************************************************************************
 * Function:getBuffer()
 * Description: function for invoking Pause API.
 * Author: Kony
 *************************************************************************************/
function getBuffer(eventobject) {
    frmVideoApi.lblDispBuffer.text = "" + frmVideoApi.video1.getBufferPercentage() + "%";
}
/*************************************************************************************
 * Function:seekToPosition()
 * Description: function to seek the video to a particular position.
 * Author: Kony
 *************************************************************************************/
function seekToPosition(eventobject) {
    var seekTime = frmVideoApi.txtSeekTo.text;
    seekTime = seekTime * 1000;
    var videoTime = frmVideoApi.video1.getDuration();
    kony.print("Seek Pos:-" + seekTime);
    try {
        seekTime = parseFloat(seekTime);
    } catch (e) {
        alert(JSON.stringify(e));
        seekTime = 0;
    }
    kony.print("Seek Pos:-" + seekTime);
    kony.print("Video len-" + videoTime);
    if (seekTime >= 1000 && seekTime <= videoTime) {
        kony.print(seekTime);
        frmVideoApi.video1.seekTo(seekTime);
        kony.print("video duration" + frmVideoApi.video1.getCurrentPosition());
    } else {
        alert("Please enter the valid position");
        return;
    }
}
/*************************************************************************************
 * Function:volumeIncrease()
 * Description: function to increase the volume of the video.
 * Author: Kony
 *************************************************************************************/
function volumeIncrease(eventobject) {
    var currentVol = frmVideoApi.video1.volume;
    if (currentVol < 1) {
        frmVideoApi.video1.volume = currentVol + 0.1;
    }
}
/*************************************************************************************
 * Function:volumeDecrease()
 * Description: function to decrease the volume of the video.
 * Author: Kony
 *************************************************************************************/
function volumeDecrease(eventobject) {
    var currentVol = frmVideoApi.video1.volume;
    if (currentVol > 0) {
        frmVideoApi.video1.volume = currentVol - 0.1;
    }
}

function setVolume() {
    var selectedVolume = frmVideoApi.slider.selectedValue;
    selectedVolume = selectedVolume / 100;
    // alert(selectedVolume);
    frmVideoApi.video1.volume = selectedVolume;
}
/*************************************************************************************
 * Function:onMute()
 * Description: function to mute the volume of the video.
 * Author: Kony
 *************************************************************************************/
function onMute(eventobject) {
    frmVideoApi.video1.volume = 0.0;
}
/*************************************************************************************
 * Function:setNewSource()
 * Description: function for setting a new source to the video.
 * Author: Kony
 *************************************************************************************/
function setNewSource(eventobject) {
    frmVideoApi.video1.setSource({
        "mp4": "movie"
    });
}

function Hide(eventobject) {
    if (frmVisibility.Video091621d6531074f.isVisible) frmVisibility.Video091621d6531074f.isVisible = false;
}
/*************************************************************************************
 * Function:visibilityHide()
 * Description: function for hiding the visibility of the video in the form.
 * Author: Kony
 *************************************************************************************/
function visibilityHide(eventobject) {
    kony.print("in hide");
    if (frmVisibilty.videoV.isVisible) frmVisibilty.videoV.isVisible = false;
}
/*************************************************************************************
 * Function:visibilityDisplay()
 * Description: function for displaying the video in the form.
 * Author: Kony
 *************************************************************************************/
function visibilityDisplay(eventobject) {
    if (!frmVisibility.videoV.isVisible) frmVisibilty.videoV.isVisible = true;
}
/*************************************************************************************
 * Function:frmVideoEvent_onerror()
 * Description: function for invoking Pause API.
 * Author: Kony
 *************************************************************************************/
function frmVideoEvent_onerror(eventobject) {
    //frmVideoEvent.Video4.isVisible=false;
    // alert("onerror");
}

function frmVideoEvent_onprepared(eventobject) {
    //frmVideoEvent.Video4.isVisible=false;
    //alert("onprepared");
}

function frmVideoEvent_oncompletion(eventobject) {
    //frmVideoEvent.Video4.isVisible=false;
    // alert("oncompletion");
}
/*************************************************************************************
 * Function:rawBytesCapture()
 * Description: This function captures the raw data taken from the camera and displays in the form.
 * Author: Kony
 *************************************************************************************/
function rawBytesCapture(eventobject) {
    frmCapture.videoDisplay.setSource({
        "rawBytes": frmCapture.camCapture.rawBytes
    });
    frmCapture.videoDisplay.setVisibility(true);
}
//video types
/*************************************************************************************
 * Function:videoTypes()
 * Description: This functon sets the MP4 format supported by Android.
 * Author: Kony
 *************************************************************************************/
function videoTypes(eventobject) {
    frmVideoTypes.videoType.setSource({
        "mov": "blackberry"
    });
}
/*************************************************************************************
 * Function:frmDynamic()
 * Description: function for invoking the video widget.
 * Author: Kony
 *************************************************************************************/
var Video6;

function frmDynamic(eventobject) {
    Video6 = new kony.ui.Video({
        "height": "40%",
        "id": "Video6",
        "isVisible": true,
        "left": "0dp",
        "skin": "slVideo",
        "source": {
            "mp4": "movie"
        },
        "text": "Video",
        "onPrepared": onPreparedCallBack,
        "onError": onErrorCallBack,
        "onCompletion": onCompletionCallBack,
        "top": "0%",
        "width": "100%",
        "controls": true,
        "poster": "defvideoposter.png",
        "volume": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmVideoEvents.add(Video6);
}

function onPreparedCallBack() {
    //alert("onPreparedCallBack");
}

function onErrorCallBack() {
    //alert("onErrorCallBack");
    kony.print("onErrorCallBack");
}

function onCompletionCallBack() {
    // alert("onCompletionCallBack");
    kony.print("onCompletionCallBack");
}

function frmdynamicEvent() {
    frmDynamic();
    frmVideoEvents.show();
}

function selectedKey(eventobject) {
    var selectedFormat = frmVideoTypes.ListBox0c9547a06dc2b4b.selectedKeyValue[1];
    if (selectedFormat == null || selectedFormat == "") {
        alert("Please select Video Type");
    }
    frmVideoTypes.flxSupported.setVisibility(true);
    if (kony.os.deviceInfo().name == "android") {
        frmVideoTypes.ListBox0c9547a06dc2b4b.masterData = [
            ["MP4", "MP4"]
        ];
    } else {
        frmVideoTypes.ListBox0c9547a06dc2b4b.masterData = [
            ["MP4", "MP4"],
            ["MOV", "MOV"]
        ];
    }
    // alert(selectedFormat);
    if (selectedFormat == "MP4") {
        // alert("setting  mp4 format");
        frmVideoTypes.videoType.setSource({
            "mp4": "http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4"
        });
    } else if (selectedFormat == "MOV") {
        frmVideoTypes.videoType.setSource({
            "mov": "big_buck_bunny"
        });
    }
}

function volume() {
    // if(frmVideoApi.flxOptions.flxVolume.isVisible == true){
    frmVideoApi.flxOptions.flxVolume.setVisibility(false);
    frmVideoApi.flxcSlider.setVisibility(true);
    // alert("in volume");
}

function slide() {
    if (frmVideoApi.flxcSlider.isVisible == true) {
        frmVideoApi.flxcSlider.setVisibility(false);
        frmVideoApi.flxVolume.setVisibility(true);
    }
}

function imageVisibility(eventobject) {
    if (frmVisibility.flxVisibility.imgVisibility.src == "switch_on.png") {
        frmVisibility.flxVisibility.imgVisibility.src = "switch_off.png";
        // visibilityHide();
        frmVisibility.videoV.isVisible = false;
    } else {
        frmVisibility.flxVisibility.imgVisibility.src = "switch_on.png";
        frmVisibility.videoV.isVisible = true;
    }
}

function frmVideoPreshow() {
    var sliderVolume = new kony.ui.Slider({
        "height": "5%",
        "id": "sliderVolume",
        "isVisible": true,
        "left": "80%",
        "leftSkin": "CopyslSliderLeftBlue0dbf09ef6cdd043",
        "max": 100,
        "min": 0,
        "onSlide": AS_Slider_a4d28a1051a54bea99dc197f1738cfe4,
        "rightSkin": "CopyslSliderRightBlue0a4b34f6f5e4c48",
        "selectedValue": 40,
        "step": 10,
        "thumbImage": "slider_android.png",
        "top": "35%",
        "width": "20%",
        "zIndex": 10
    }, {}, {
        "thickness": 15,
        orientation: constants.SLIDER_VERTICAL_ORIENTATION
    });
    frmTest.add(sliderVolume);
}