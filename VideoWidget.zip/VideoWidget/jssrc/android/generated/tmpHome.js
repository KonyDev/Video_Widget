function initializetmpHome() {
    flxHome = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxHome",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox05d367ce94e4b41"
    }, {}, {});
    flxHome.setDefaultUnit(kony.flex.DP);
    var Label0be236450549244 = new kony.ui.Label({
        "height": "100%",
        "id": "Label0be236450549244",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0e42b5586181448",
        "text": "Video  Widget",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "6%",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [5, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxHome.add(Label0be236450549244);
}