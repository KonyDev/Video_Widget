function addWidgetsfrmVisibility() {
    frmVisibility.setDefaultUnit(kony.flex.DP);
    var videoV = new kony.ui.Video({
        "height": "35%",
        "id": "videoV",
        "isVisible": true,
        "left": "0%",
        "skin": "slVideo",
        "source": {
            "mp4": "http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4"
        },
        "text": "Video",
        "top": "0%",
        "width": "100%",
        "controls": true,
        "poster": "defvideoposter.png",
        "volume": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flxVisibility = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9%",
        "id": "flxVisibility",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0eac78aab48a041",
        "top": "35%",
        "width": "100%"
    }, {}, {});
    flxVisibility.setDefaultUnit(kony.flex.DP);
    var CopylblVideoApi05dc73aec0eaf43 = new kony.ui.Label({
        "height": "93%",
        "id": "CopylblVideoApi05dc73aec0eaf43",
        "isVisible": true,
        "left": "6.00%",
        "skin": "CopyslLabel0283360c36f3946",
        "text": "Video Visibility",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "7.21%",
        "width": "94%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel005059c480ccb4f = new kony.ui.Label({
        "height": "1%",
        "id": "CopyLabel005059c480ccb4f",
        "isVisible": true,
        "left": "5.00%",
        "skin": "CopyslLabel0f19631990a5f44",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "100%",
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var imgVisibility = new kony.ui.Image2({
        "height": "100%",
        "id": "imgVisibility",
        "isVisible": true,
        "left": "80%",
        "onTouchEnd": AS_Image_2be82cb1da774bbf84922e4927d08b36,
        "skin": "slImage",
        "src": "switch_on.png",
        "top": "0%",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxVisibility.add(CopylblVideoApi05dc73aec0eaf43, CopyLabel005059c480ccb4f, imgVisibility);
    frmVisibility.add(videoV, flxVisibility);
};

function frmVisibilityGlobals() {
    frmVisibility = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmVisibility,
        "enabledForIdleTimeout": false,
        "headers": [flxVideoVisibility],
        "id": "frmVisibility",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0fc80b55c8b0441",
        "title": "Video Visibility"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0e1952b5d7e8d4c",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};