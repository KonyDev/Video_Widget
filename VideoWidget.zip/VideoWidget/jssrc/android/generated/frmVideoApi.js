function addWidgetsfrmVideoApi() {
    frmVideoApi.setDefaultUnit(kony.flex.DP);
    var video1 = new kony.ui.Video({
        "height": "210dp",
        "id": "video1",
        "isVisible": true,
        "left": "0%",
        "skin": "slVideo",
        "source": {
            "mp4": "http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4"
        },
        "text": "Video",
        "top": "0%",
        "width": "100%",
        "controls": false,
        "volume": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flxApis = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "340dp",
        "id": "flxApis",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox00b2532d4806a47",
        "top": "210dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxApis.setDefaultUnit(kony.flex.DP);
    var flxGetPosition = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxGetPosition",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_75a5cd64e0844d1bae901359274878ee,
        "skin": "slFbox",
        "top": "14%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxGetPosition.setDefaultUnit(kony.flex.DP);
    var Label04e4065cb237445 = new kony.ui.Label({
        "height": "100%",
        "id": "Label04e4065cb237445",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ab48c484ef664f",
        "text": "Get Position",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "60%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblDispPosition = new kony.ui.Label({
        "height": "100%",
        "id": "lblDispPosition",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b7c19c5ebf8e49",
        "text": " ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [11, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0c7346d86c7c141 = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "Label0c7346d86c7c141",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0a23beac341b149",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGetPosition.add(Label04e4065cb237445, lblDispPosition, Label0c7346d86c7c141);
    var flxGetDuration = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxGetDuration",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_d88073ce815e4e228284cafdab0921c2,
        "skin": "slFbox",
        "top": "28%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxGetDuration.setDefaultUnit(kony.flex.DP);
    var CopyLabel0c520ce1ed9c440 = new kony.ui.Label({
        "height": "100%",
        "id": "CopyLabel0c520ce1ed9c440",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ab48c484ef664f",
        "text": "Get Duration",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "60%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblDispDuration = new kony.ui.Label({
        "height": "100%",
        "id": "lblDispDuration",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b7c19c5ebf8e49",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [11, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel041a85e48e73341 = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel041a85e48e73341",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ec2252b806e847",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGetDuration.add(CopyLabel0c520ce1ed9c440, lblDispDuration, CopyLabel041a85e48e73341);
    var flxVideoPlaying = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxVideoPlaying",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_82e7a40586634994b0c3323e76401ed3,
        "skin": "slFbox",
        "top": "42%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxVideoPlaying.setDefaultUnit(kony.flex.DP);
    var CopyLabel0ea4469cd9a2043 = new kony.ui.Label({
        "height": "100%",
        "id": "CopyLabel0ea4469cd9a2043",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ab48c484ef664f",
        "text": "Video Playing",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "60%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblDispPlaying = new kony.ui.Label({
        "height": "100%",
        "id": "lblDispPlaying",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b7c19c5ebf8e49",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [11, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0631c28d3345b4a = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel0631c28d3345b4a",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0efd5a24a33ca4b",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxVideoPlaying.add(CopyLabel0ea4469cd9a2043, lblDispPlaying, CopyLabel0631c28d3345b4a);
    var flxGetBuffering = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxGetBuffering",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_21f542d893414a539a37dab7389419fc,
        "skin": "slFbox",
        "top": "56%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxGetBuffering.setDefaultUnit(kony.flex.DP);
    var CopyLabel0cb90c31a936047 = new kony.ui.Label({
        "height": "100%",
        "id": "CopyLabel0cb90c31a936047",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ab48c484ef664f",
        "text": "Get Buffering",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "60%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblDispBuffer = new kony.ui.Label({
        "height": "100%",
        "id": "lblDispBuffer",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0b7c19c5ebf8e49",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [11, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0762869ee2fe94e = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel0762869ee2fe94e",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0150aec0fc9b343",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGetBuffering.add(CopyLabel0cb90c31a936047, lblDispBuffer, CopyLabel0762869ee2fe94e);
    var flxSeekTo = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxSeekTo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_ccc9bec3cb494a9699508dc1b545299e,
        "skin": "CopyslFbox05182443809a94a",
        "top": "70%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSeekTo.setDefaultUnit(kony.flex.DP);
    var CopyLabel03a077ee0c08344 = new kony.ui.Label({
        "height": "100%",
        "id": "CopyLabel03a077ee0c08344",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ab48c484ef664f",
        "text": "Seek to Position",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "60%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel075cdbae4b61f40 = new kony.ui.Label({
        "bottom": "1%",
        "height": "1%",
        "id": "CopyLabel075cdbae4b61f40",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0f0410d9f89744a",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "95%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var txtSeekTo = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "70%",
        "id": "txtSeekTo",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "68%",
        "placeholder": "0",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0d88f97d3c5a149",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "13%",
        "width": "28%",
        "zIndex": 10
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [11, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    flxSeekTo.add(CopyLabel03a077ee0c08344, CopyLabel075cdbae4b61f40, txtSeekTo);
    var flxNewSource = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxNewSource",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_7099062c66534cc7aafe9507a9b77dc9,
        "skin": "slFbox",
        "top": "84%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxNewSource.setDefaultUnit(kony.flex.DP);
    var CopyLabel00b923f724c0247 = new kony.ui.Label({
        "height": "100%",
        "id": "CopyLabel00b923f724c0247",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel0ab48c484ef664f",
        "text": "New Source",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "95%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel025afc99aa18d46 = new kony.ui.Label({
        "bottom": "47%",
        "height": "1%",
        "id": "CopyLabel025afc99aa18d46",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel02286924cc0b542",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "145%",
        "width": "100%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxNewSource.add(CopyLabel00b923f724c0247, CopyLabel025afc99aa18d46);
    var flxOptions = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "14%",
        "id": "flxOptions",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox09b8ea0fe07ff4a",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOptions.setDefaultUnit(kony.flex.DP);
    var flxPlay = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxPlay",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "13%",
        "onClick": AS_FlexContainer_772603621f454666a337e89d7ab610c3,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    flxPlay.setDefaultUnit(kony.flex.DP);
    var Image0435fe06cca3b43 = new kony.ui.Image2({
        "height": "100%",
        "id": "Image0435fe06cca3b43",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "play.png",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPlay.add(Image0435fe06cca3b43);
    var flxPause = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxPause",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "38%",
        "onClick": AS_FlexContainer_d5dc46a2dffa42ccac66c53494de69ff,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    flxPause.setDefaultUnit(kony.flex.DP);
    var CopyImage0677ad6bf8cf847 = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage0677ad6bf8cf847",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "pause.png",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPause.add(CopyImage0677ad6bf8cf847);
    var flxStop = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxStop",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "60%",
        "onClick": AS_FlexContainer_1b11dd002ff9447ca4bdacfa55b4ef4f,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    flxStop.setDefaultUnit(kony.flex.DP);
    var CopyImage0894dcb5049664b = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage0894dcb5049664b",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "stop.png",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxStop.add(CopyImage0894dcb5049664b);
    var flxVolume = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxVolume",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "80%",
        "onClick": AS_FlexContainer_c255a98c9c424323b51dc95c7cca26d5,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 2
    }, {}, {});
    flxVolume.setDefaultUnit(kony.flex.DP);
    var CopyImage07163878ad5eb45 = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage07163878ad5eb45",
        "isVisible": true,
        "left": "0.00%",
        "skin": "slImage",
        "src": "volume.png",
        "top": "0.37%",
        "width": "100%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxVolume.add(CopyImage07163878ad5eb45);
    var flxcSlider = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxcSlider",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "right": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "30%",
        "zIndex": 20
    }, {}, {});
    flxcSlider.setDefaultUnit(kony.flex.DP);
    var slider = new kony.ui.Slider({
        "centerX": "50%",
        "height": "50%",
        "id": "slider",
        "isVisible": true,
        "leftSkin": "CopyslSliderLeftBlue06239baf060bb47",
        "max": 100,
        "min": 0,
        "onSelection": AS_Slider_6e378cc6035e49cdbf42cea92301c258,
        "onSlide": AS_Slider_a7f75b020e4e4d6c807a5b0f666032ca,
        "rightSkin": "CopyslSliderRightBlue0d5c322a2a13b44",
        "selectedValue": 40,
        "step": 10,
        "thumbImage": "cursor.png",
        "top": "30%",
        "width": "80%",
        "zIndex": 50
    }, {}, {
        "thickness": 15
    });
    flxcSlider.add(slider);
    flxOptions.add(flxPlay, flxPause, flxStop, flxVolume, flxcSlider);
    flxApis.add(flxGetPosition, flxGetDuration, flxVideoPlaying, flxGetBuffering, flxSeekTo, flxNewSource, flxOptions);
    frmVideoApi.add(video1, flxApis);
};

function frmVideoApiGlobals() {
    frmVideoApi = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmVideoApi,
        "enabledForIdleTimeout": false,
        "headers": [flxVideoApi],
        "id": "frmVideoApi",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0d630a67ff7aa4e",
        "title": "Video API"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar015064a70708349",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};