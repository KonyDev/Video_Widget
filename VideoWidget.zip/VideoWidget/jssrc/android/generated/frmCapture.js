function addWidgetsfrmCapture() {
    frmCapture.setDefaultUnit(kony.flex.DP);
    var FlexContainer07eeee647c63b49 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "FlexContainer07eeee647c63b49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer07eeee647c63b49.setDefaultUnit(kony.flex.DP);
    var videoDisplay = new kony.ui.Video({
        "height": "100%",
        "id": "videoDisplay",
        "isVisible": false,
        "left": "0%",
        "onPrepared": AS_Video_3bb973611c8647e48cef6a2a9bf1ce03,
        "onError": AS_Video_3b3d27e55a314787934e3e2c6c076d56,
        "onCompletion": AS_Video_6f60f167a29849219fb9f17dd4cfcae2,
        "skin": "CopyslVideo0a590c432626245",
        "text": "Video",
        "top": "0%",
        "width": "100%",
        "zIndex": 1,
        "controls": true,
        "poster": "defvideoposter.png",
        "volume": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer07eeee647c63b49.add(videoDisplay);
    var camCapture = new kony.ui.Camera({
        "captureMode": constants.CAMERA_CAPTURE_MODE_VIDEO,
        "height": "9%",
        "id": "camCapture",
        "isVisible": true,
        "left": "25.05%",
        "onCapture": AS_Camera_9553db9ce0de449aab93ab7bfa51e473,
        "skin": "CopyslCamera002b97c5a229347",
        "text": "Capture",
        "top": "45.03%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "accessMode": constants.CAMERA_IMAGE_ACCESS_MODE_PUBLIC,
        "enableOverlay": false,
        "enablePhotoCropFeature": false
    });
    frmCapture.add(FlexContainer07eeee647c63b49, camCapture);
};

function frmCaptureGlobals() {
    frmCapture = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCapture,
        "enabledForIdleTimeout": false,
        "headers": [flxRawBytes],
        "id": "frmCapture",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0ec46ecf066d942",
        "title": "RawBytes"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0e587e0377ce049",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};