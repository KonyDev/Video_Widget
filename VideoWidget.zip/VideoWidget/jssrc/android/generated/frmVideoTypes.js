function addWidgetsfrmVideoTypes() {
    frmVideoTypes.setDefaultUnit(kony.flex.DP);
    var btnDone = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0b04a649018354c",
        "height": "9%",
        "id": "btnDone",
        "isVisible": true,
        "left": "22%",
        "onClick": AS_Button_bc8c2ed6397a4dc793da90bcbe1bf692,
        "skin": "CopyslButtonGlossBlue01f5a124ad37847",
        "text": "Done",
        "top": "86%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var ListBox0c9547a06dc2b4b = new kony.ui.ListBox({
        "height": "6%",
        "id": "ListBox0c9547a06dc2b4b",
        "isVisible": true,
        "left": "17.97%",
        "masterData": [
            ["MP4", "MP4"],
            ["MOV", "MOV"]
        ],
        "skin": "slListBox",
        "top": "70.02%",
        "width": "60%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "applySkinsToPopup": true,
        "placeholder": "Select Format",
        "viewType": constants.LISTBOX_VIEW_TYPE_LISTVIEW
    });
    var flxOriginal = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "32%",
        "id": "flxOriginal",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 100
    }, {}, {});
    flxOriginal.setDefaultUnit(kony.flex.DP);
    var Video0240c1dbe7d8640 = new kony.ui.Video({
        "height": "100%",
        "id": "Video0240c1dbe7d8640",
        "isVisible": true,
        "left": "0%",
        "skin": "slVideo",
        "source": {
            "mp4": "http://www.quirksmode.org/html5/videos/big_buck_bunny.mp4"
        },
        "text": "Video",
        "top": "0%",
        "width": "100%",
        "controls": true,
        "poster": "defvideoposter.png",
        "volume": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label07ed376007b4246 = new kony.ui.Label({
        "height": "13%",
        "id": "Label07ed376007b4246",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel044966b9545d748",
        "text": "Original Video",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "3%",
        "width": "95%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxOriginal.add(Video0240c1dbe7d8640, Label07ed376007b4246);
    var flxSupported = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "32%",
        "id": "flxSupported",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "34%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSupported.setDefaultUnit(kony.flex.DP);
    var videoType = new kony.ui.Video({
        "height": "100%",
        "id": "videoType",
        "isVisible": true,
        "left": "0dp",
        "skin": "slVideo",
        "text": "Video",
        "top": "0dp",
        "width": "100%",
        "zIndex": 4,
        "controls": true,
        "poster": "defvideoposter.png",
        "volume": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0338f23b5f30646 = new kony.ui.Label({
        "height": "13%",
        "id": "CopyLabel0338f23b5f30646",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel06793400562ed49",
        "text": "Supported Format",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "3%",
        "width": "95%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxSupported.add(videoType, CopyLabel0338f23b5f30646);
    frmVideoTypes.add(btnDone, ListBox0c9547a06dc2b4b, flxOriginal, flxSupported);
};

function frmVideoTypesGlobals() {
    frmVideoTypes = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmVideoTypes,
        "enabledForIdleTimeout": false,
        "headers": [flxVideoTypes],
        "id": "frmVideoTypes",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "postShow": AS_Form_852fea80c47d4cc490d4ecb38d5f58e0,
        "skin": "CopyslForm045b8b8fad3d140",
        "title": "Video Types"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "CopyslTitleBar0a0aa09bdeb2947",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
    frmVideoTypes.info = {
        "kuid": "6d6b920883024947b73cf9e0d4f1a104"
    };
};