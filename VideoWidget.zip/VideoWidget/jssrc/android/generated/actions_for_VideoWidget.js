//actions.js file 
function AS_Button_76c6de776edb4848b2e90c164eb13126(eventobject) {
    return frmdynamicEvent.call(this);
}

function AS_Button_bc8c2ed6397a4dc793da90bcbe1bf692(eventobject) {
    return selectedKey.call(this, null);
}

function AS_Button_f784d9ea97cc49f5ba1dc63e808316f8(eventobject) {
    return selectedKey.call(this, null);
}

function AS_Camera_9553db9ce0de449aab93ab7bfa51e473(eventobject) {
    return rawBytesCapture.call(this, null);
}

function AS_FlexContainer_15e6493ee5b441acabf8858b407ca530(eventobject) {
    frmHome.show();
}

function AS_FlexContainer_1b11dd002ff9447ca4bdacfa55b4ef4f(eventobject) {
    return onStop.call(this, null);
}

function AS_FlexContainer_21f542d893414a539a37dab7389419fc(eventobject) {
    return getBuffer.call(this, null);
}

function AS_FlexContainer_429ba33b602a4b4ea74b113c18f0f911(eventobject) {
    frmVideoTypes.show();
}

function AS_FlexContainer_454f0b9a4b6c4559b11d5833706d196a(eventobject) {
    frmCapture.show();
}

function AS_FlexContainer_53e592e3f2fc4031a88e19e01e481690(eventobject) {
    frmHome.show();
}

function AS_FlexContainer_7099062c66534cc7aafe9507a9b77dc9(eventobject) {
    return setNewSource.call(this, null);
}

function AS_FlexContainer_75a5cd64e0844d1bae901359274878ee(eventobject) {
    return getPosition.call(this, null);
}

function AS_FlexContainer_772603621f454666a337e89d7ab610c3(eventobject) {
    return onPlay.call(this, null);
}

function AS_FlexContainer_82e7a40586634994b0c3323e76401ed3(eventobject) {
    return videoPlaying.call(this, null);
}

function AS_FlexContainer_888e079fd2ec48fab7d044989eacaa84(eventobject) {
    frmVideoEvents.show();
}

function AS_FlexContainer_abaab5c8d73843a0a391d32d89872ec2(eventobject) {
    frmHome.show();
}

function AS_FlexContainer_b3a9b83fc5b442148781be04137b4b48(eventobject) {
    frmVideoApi.show();
}

function AS_FlexContainer_c255a98c9c424323b51dc95c7cca26d5(eventobject) {
    return volume.call(this);
}

function AS_FlexContainer_ccc9bec3cb494a9699508dc1b545299e(eventobject) {
    return seekToPosition.call(this, null);
}

function AS_FlexContainer_d4f97c2ac1f14eddb13f5ac2583535d9(eventobject) {
    frmVisibility.show();
}

function AS_FlexContainer_d5dc46a2dffa42ccac66c53494de69ff(eventobject) {
    return onPause.call(this, null);
}

function AS_FlexContainer_d7a8ba0f25b24fac9553bcdf68a93e99(eventobject) {
    frmHome.show();
}

function AS_FlexContainer_d88073ce815e4e228284cafdab0921c2(eventobject) {
    return getDuration.call(this, null);
}

function AS_FlexContainer_f8a7ff6dacc34981aa3fba85f7737f0a(eventobject) {
    frmHome.show();
}

function AS_Form_0363799679bd422a9492adcabd45cc96(eventobject) {
    return visibilityDisplay.call(this, null);
}

function AS_Form_5c218b6b425d4a38b667641227254e66(eventobject) {
    return frmVideoPreshow.call(this);
}

function AS_Form_852fea80c47d4cc490d4ecb38d5f58e0(eventobject) {
    if (kony.os.deviceInfo().name == "android") {
        frmVideoTypes.ListBox0c9547a06dc2b4b.masterData = [
            ["MP4", "MP4"]
        ];
    } else {
        frmVideoTypes.ListBox0c9547a06dc2b4b.masterData = [
            ["MP4", "MP4"],
            ["MOV", "MOV"]
        ];
    }
}

function AS_Image_2be82cb1da774bbf84922e4927d08b36(eventobject, x, y) {
    return imageVisibility.call(this, null);
}

function AS_Slider_2893d87e58824cf6a03508d8ec98919a(eventobject, selectedvalue) {
    return setVolume.call(this);
}

function AS_Slider_6e378cc6035e49cdbf42cea92301c258(eventobject, selectedvalue) {
    return slide.call(this);
}

function AS_Slider_a2cf8131f2a54a5f8b82049db0aa1d5d(eventobject, selectedvalue) {
    return slide.call(this);
}

function AS_Slider_a7f75b020e4e4d6c807a5b0f666032ca(eventobject, selectedvalue) {
    return setVolume.call(this);
}

function AS_Video_3b3d27e55a314787934e3e2c6c076d56(eventobject) {
    return frmVideoEvent_onerror.call(this, null);
}

function AS_Video_3bb973611c8647e48cef6a2a9bf1ce03(eventobject) {
    return frmVideoEvent_onprepared.call(this, null);
}

function AS_Video_6f60f167a29849219fb9f17dd4cfcae2(eventobject) {
    return frmVideoEvent_oncompletion.call(this, null);
}