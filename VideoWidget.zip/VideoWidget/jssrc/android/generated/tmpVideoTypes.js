function initializetmpVideoTypes() {
    flxVideoTypes = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxVideoTypes",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox022e7c9609b634c"
    }, {}, {});
    flxVideoTypes.setDefaultUnit(kony.flex.DP);
    var Label029432494224144 = new kony.ui.Label({
        "height": "100%",
        "id": "Label029432494224144",
        "isVisible": true,
        "left": "15%",
        "skin": "CopyslLabel03a3545beda584c",
        "text": "Video Type",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "85%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var flxBack = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxBack",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_d7a8ba0f25b24fac9553bcdf68a93e99,
        "skin": "slFbox",
        "top": "0%",
        "width": "15%",
        "zIndex": 1
    }, {}, {});
    flxBack.setDefaultUnit(kony.flex.DP);
    var Image03e3ed25a15264b = new kony.ui.Image2({
        "height": "100%",
        "id": "Image03e3ed25a15264b",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "back.png",
        "top": "0%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBack.add(Image03e3ed25a15264b);
    flxVideoTypes.add(Label029432494224144, flxBack);
}