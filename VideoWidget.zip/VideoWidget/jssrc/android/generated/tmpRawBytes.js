function initializetmpRawBytes() {
    flxRawBytes = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "flxRawBytes",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox022e7c9609b634c"
    }, {}, {});
    flxRawBytes.setDefaultUnit(kony.flex.DP);
    var Label029432494224144 = new kony.ui.Label({
        "height": "100%",
        "id": "Label029432494224144",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel03a3545beda584c",
        "text": "RawBytes",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "90%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [2, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var flxBack = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxBack",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_15e6493ee5b441acabf8858b407ca530,
        "skin": "slFbox",
        "top": "0%",
        "width": "10%",
        "zIndex": 1
    }, {}, {});
    flxBack.setDefaultUnit(kony.flex.DP);
    var Image03e3ed25a15264b = new kony.ui.Image2({
        "height": "100%",
        "id": "Image03e3ed25a15264b",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "back.png",
        "top": "0%",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBack.add(Image03e3ed25a15264b);
    flxRawBytes.add(Label029432494224144, flxBack);
}