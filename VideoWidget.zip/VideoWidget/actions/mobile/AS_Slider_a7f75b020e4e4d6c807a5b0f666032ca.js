function AS_Slider_a7f75b020e4e4d6c807a5b0f666032ca(eventobject, selectedvalue) {
    return setVolume.call(this);
}