function AS_FlexContainer_d88073ce815e4e228284cafdab0921c2(eventobject) {
    return getDuration.call(this, null);
}