function AS_Button_76c6de776edb4848b2e90c164eb13126(eventobject) {
    return frmdynamicEvent.call(this);
}