function AS_Image_2be82cb1da774bbf84922e4927d08b36(eventobject, x, y) {
    return imageVisibility.call(this, null);
}