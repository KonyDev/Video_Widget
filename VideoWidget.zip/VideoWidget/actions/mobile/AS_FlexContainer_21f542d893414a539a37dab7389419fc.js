function AS_FlexContainer_21f542d893414a539a37dab7389419fc(eventobject) {
    return getBuffer.call(this, null);
}