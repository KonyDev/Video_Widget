function AS_Video_6f60f167a29849219fb9f17dd4cfcae2(eventobject) {
    return frmVideoEvent_oncompletion.call(this, null);
}