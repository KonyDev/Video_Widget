function AS_Camera_9553db9ce0de449aab93ab7bfa51e473(eventobject) {
    return rawBytesCapture.call(this, null);
}