function AS_Video_3bb973611c8647e48cef6a2a9bf1ce03(eventobject) {
    return frmVideoEvent_onprepared.call(this, null);
}