function AS_FlexContainer_454f0b9a4b6c4559b11d5833706d196a(eventobject) {
    frmCapture.show();
}