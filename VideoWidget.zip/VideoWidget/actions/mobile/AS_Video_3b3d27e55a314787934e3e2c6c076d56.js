function AS_Video_3b3d27e55a314787934e3e2c6c076d56(eventobject) {
    return frmVideoEvent_onerror.call(this, null);
}