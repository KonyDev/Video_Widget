function AS_Form_5c218b6b425d4a38b667641227254e66(eventobject) {
    return frmVideoPreshow.call(this);
}