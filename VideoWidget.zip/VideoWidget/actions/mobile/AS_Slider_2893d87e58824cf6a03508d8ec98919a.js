function AS_Slider_2893d87e58824cf6a03508d8ec98919a(eventobject, selectedvalue) {
    return setVolume.call(this);
}