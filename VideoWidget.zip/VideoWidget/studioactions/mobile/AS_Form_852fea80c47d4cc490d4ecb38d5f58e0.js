function AS_Form_852fea80c47d4cc490d4ecb38d5f58e0(eventobject) {
    if (kony.os.deviceInfo().name == "android") {
        frmVideoTypes.ListBox0c9547a06dc2b4b.masterData = [
            ["MP4", "MP4"]
        ];
    } else {
        frmVideoTypes.ListBox0c9547a06dc2b4b.masterData = [
            ["MP4", "MP4"],
            ["MOV", "MOV"]
        ];
    }
}