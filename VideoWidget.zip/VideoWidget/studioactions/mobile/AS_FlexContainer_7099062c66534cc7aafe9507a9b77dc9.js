function AS_FlexContainer_7099062c66534cc7aafe9507a9b77dc9(eventobject) {
    return setNewSource.call(this, null);
}