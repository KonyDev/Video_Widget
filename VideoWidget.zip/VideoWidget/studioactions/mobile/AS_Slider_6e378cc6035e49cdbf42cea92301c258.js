function AS_Slider_6e378cc6035e49cdbf42cea92301c258(eventobject, selectedvalue) {
    return slide.call(this);
}