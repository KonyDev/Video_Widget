function AS_Slider_a2cf8131f2a54a5f8b82049db0aa1d5d(eventobject, selectedvalue) {
    return slide.call(this);
}